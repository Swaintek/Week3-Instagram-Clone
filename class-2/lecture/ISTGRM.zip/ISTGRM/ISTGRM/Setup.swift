//
//  Setup.swift
//  ISTGRM
//
//  Created by Michael Babiy on 6/20/16.
//  Copyright © 2016 Michael Babiy. All rights reserved.
//

import Foundation

protocol Setup
{
    func setup()
    func setupAppearance()
}