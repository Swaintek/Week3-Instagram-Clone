//
//  Post.swift
//  ISTGRM
//
//  Created by Adam Wallraff on 6/21/16.
//  Copyright © 2016 Michael Babiy. All rights reserved.
//

import UIKit

class Post {
    
    let image : UIImage
    
    init(image: UIImage)
    {
        self.image = image
    }
    
}
